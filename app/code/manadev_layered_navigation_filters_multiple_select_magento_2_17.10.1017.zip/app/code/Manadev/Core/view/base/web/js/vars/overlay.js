define(['Manadev_Core/js/Overlay'], function(Overlay) {
    return new Overlay();
});