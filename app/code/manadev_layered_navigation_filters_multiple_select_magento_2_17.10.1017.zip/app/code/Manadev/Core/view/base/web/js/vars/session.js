define(['Manadev_Core/js/Session'], function(Session) {
    return new Session();
});