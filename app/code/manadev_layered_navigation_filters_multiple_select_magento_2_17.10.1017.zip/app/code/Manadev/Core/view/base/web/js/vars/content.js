define(['Manadev_Core/js/Content'], function(Content) {
    return new Content(window.manaContent);
});